
import React, { useState } from "react";

export default function JournalApp() {
  const [entry, setEntry] = useState("");
  const [mood, setMood] = useState(3);

  const submitEntry = () => {
    console.log("Entry submitted:", { entry, mood });
    alert("Journal saved!");
  };

  return (
    <div>
      <h1>Student Wellness Journal</h1>
      <label>Mood (1-5)</label>
      <input type="number" min="1" max="5" onChange={(e)=>setMood(e.target.value)} />
      <br/>
      <textarea placeholder="Write today's feelings..." 
      onChange={(e)=>setEntry(e.target.value)} />
      <br/>
      <button onClick={submitEntry}>Save Entry</button>
    </div>
  );
}
