
# Student Wellness Tracking App

A journaling system where students log daily mood and habits. The system analyzes patterns,
predicts stress peaks, and suggests coping micro‑tasks.

## Tech Stack
Frontend: React
Backend: Node.js (Express)
Database: PostgreSQL
AI APIs: NLP / ML APIs for mood pattern detection

## Features
- Daily mood journal
- Habit tracker
- Stress prediction
- Personalized coping suggestions
- Interactive timeline visualization

## Example Stress Situations & Solutions

### 1. Exam Stress
Problem: Student logs anxiety before exams.
AI Pattern: Increased negative mood entries near exam dates.
Solution Suggestions:
- 10 minute breathing exercise
- Study planning micro‑task
- Short break reminder

### 2. Sleep Deprivation
Problem: Mood logs show tiredness for multiple days.
AI Pattern: Low mood + late night habit logs.
Solution Suggestions:
- Sleep routine reminder
- Screen time reduction
- Meditation task

### 3. Academic Overload
Problem: Multiple assignments logged in short period.
AI Pattern: Stress spike prediction.
Solution Suggestions:
- Break tasks into smaller goals
- Pomodoro study timer
- Walk / relaxation micro‑task

## Data Stored
- mood_level (1-5)
- habits_completed
- journal_text
- timestamp

## Outputs
- Stress trend graph
- Mood timeline
- AI wellness suggestions
