
const express = require("express");
const app = express();
app.use(express.json());

let journalEntries = [];

app.post("/journal", (req,res)=>{
    const entry = req.body;
    journalEntries.push(entry);
    res.json({message:"Entry stored"});
});

app.get("/analysis",(req,res)=>{
    res.json({
        insight:"Stress levels increasing this week",
        suggestion:"Take a 10 minute break and breathing exercise"
    });
});

app.listen(3000,()=>{
    console.log("Server running on port 3000");
});
